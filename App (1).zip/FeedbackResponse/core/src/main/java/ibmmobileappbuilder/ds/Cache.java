package ibmmobileappbuilder.ds;

/**
 * This interface mark the datasource as cacheable
 */
public interface Cache {

    void invalidate();
}
