package com.ibm.mobileappbuilder.testfeedback20160930045915.ui;

import android.support.v4.app.Fragment;
import android.util.SparseArray;

import ibmmobileappbuilder.ui.DrawerActivity;

import com.ibm.mobileappbuilder.testfeedback20160930045915.ds.ResponsetofeedbackDSSchemaItem;
import com.ibm.mobileappbuilder.testfeedback20160930045915.ds.TestfeedbackDSSchemaItem;
import com.ibm.mobileappbuilder.testfeedback20160930045915.R;

public class FeedbackResponseMain extends DrawerActivity {

    private final SparseArray<Class<? extends Fragment>> sectionFragments = new SparseArray<>();
    {
                sectionFragments.append(R.id.entry0, UserfeedbacksFragment.class);
            sectionFragments.append(R.id.entry1, ResponseFragment.class);
    }

    @Override
    public SparseArray<Class<? extends Fragment>> getSectionFragmentClasses() {
      return sectionFragments;
    }

}

