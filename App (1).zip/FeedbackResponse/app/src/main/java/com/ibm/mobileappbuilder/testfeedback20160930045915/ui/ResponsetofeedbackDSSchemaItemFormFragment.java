
package com.ibm.mobileappbuilder.testfeedback20160930045915.ui;
import android.annotation.SuppressLint;
import android.os.Bundle;
import android.text.Editable;
import android.view.View;
import com.ibm.mobileappbuilder.testfeedback20160930045915.presenters.ResponseFormPresenter;
import com.ibm.mobileappbuilder.testfeedback20160930045915.R;
import ibmmobileappbuilder.ds.CloudantDatasource;
import ibmmobileappbuilder.ui.FormFragment;
import ibmmobileappbuilder.views.TextWatcherAdapter;
import ibmmobileappbuilder.ds.Datasource;
import ibmmobileappbuilder.ds.CrudDatasource;
import ibmmobileappbuilder.ds.SearchOptions;
import ibmmobileappbuilder.ds.filter.Filter;
import java.util.Arrays;
import com.ibm.mobileappbuilder.testfeedback20160930045915.ds.ResponsetofeedbackDSSchemaItem;
import ibmmobileappbuilder.ds.CloudantDatasource;
import ibmmobileappbuilder.cloudant.factory.CloudantDatastoresFactory;
import java.net.URI;
import static ibmmobileappbuilder.analytics.injector.PageViewBehaviorInjector.pageViewBehavior;

public class ResponsetofeedbackDSSchemaItemFormFragment extends FormFragment<ResponsetofeedbackDSSchemaItem> {

    private CrudDatasource<ResponsetofeedbackDSSchemaItem> datasource;

    public static ResponsetofeedbackDSSchemaItemFormFragment newInstance(Bundle args){
        ResponsetofeedbackDSSchemaItemFormFragment fr = new ResponsetofeedbackDSSchemaItemFormFragment();
        fr.setArguments(args);

        return fr;
    }

    public ResponsetofeedbackDSSchemaItemFormFragment(){
        super();
    }

    @Override
    public void onCreate(Bundle state) {
        super.onCreate(state);

        // the presenter for this view
        setPresenter(new ResponseFormPresenter(
                (CrudDatasource) getDatasource(),
                this));

        addBehavior(pageViewBehavior("Response"));
    }

    @Override
    protected ResponsetofeedbackDSSchemaItem newItem() {
        return new ResponsetofeedbackDSSchemaItem();
    }

    @Override
    protected int getLayout() {
        return R.layout.response_form;
    }

    @Override
    @SuppressLint("WrongViewCast")
    public void bindView(final ResponsetofeedbackDSSchemaItem item, View view) {
        
        bindString(R.id.customername, item.customer_name, new TextWatcherAdapter() {
            @Override
            public void afterTextChanged(Editable s) {
                item.customer_name = s.toString();
            }
        });
        
        
        bindString(R.id.customercontact, item.customer_contact, new TextWatcherAdapter() {
            @Override
            public void afterTextChanged(Editable s) {
                item.customer_contact = s.toString();
            }
        });
        
        
        bindString(R.id.customeremail, item.customer_email, new TextWatcherAdapter() {
            @Override
            public void afterTextChanged(Editable s) {
                item.customer_email = s.toString();
            }
        });
        
        
        bindString(R.id.customersatisfaction, item.customer_satisfaction, new TextWatcherAdapter() {
            @Override
            public void afterTextChanged(Editable s) {
                item.customer_satisfaction = s.toString();
            }
        });
        
    }

    @Override
    public Datasource<ResponsetofeedbackDSSchemaItem> getDatasource() {
      if (datasource != null) {
        return datasource;
      }
       datasource = CloudantDatasource.cloudantDatasource(
              CloudantDatastoresFactory.create("responseforfeedback"),
              URI.create("https://dfe9cdad-0e3d-4ed2-8a81-818a2ed88267-bluemix:887073ee3dc99c65d4becdaa936c89d52359015007e10e44de1445f2c1f04417@dfe9cdad-0e3d-4ed2-8a81-818a2ed88267-bluemix.cloudant.com/responseforfeedback"),
              ResponsetofeedbackDSSchemaItem.class,
              new SearchOptions(),
              null
      );
        return datasource;
    }
}

