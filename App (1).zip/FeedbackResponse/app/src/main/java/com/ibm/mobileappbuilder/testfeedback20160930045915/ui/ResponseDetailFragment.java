
package com.ibm.mobileappbuilder.testfeedback20160930045915.ui;
import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.FragmentActivity;
import android.view.View;
import android.widget.TextView;
import com.ibm.mobileappbuilder.testfeedback20160930045915.presenters.ResponseDetailPresenter;
import com.ibm.mobileappbuilder.testfeedback20160930045915.R;
import ibmmobileappbuilder.behaviors.FabBehaviour;
import ibmmobileappbuilder.behaviors.ShareBehavior;
import ibmmobileappbuilder.mvp.presenter.DetailCrudPresenter;
import ibmmobileappbuilder.util.Constants;
import ibmmobileappbuilder.ds.Datasource;
import ibmmobileappbuilder.ds.CrudDatasource;
import ibmmobileappbuilder.analytics.injector.AnalyticsReporterInjector;
import ibmmobileappbuilder.analytics.AnalyticsReporter;
import static ibmmobileappbuilder.analytics.model.AnalyticsInfo.Builder.analyticsInfo;
import static ibmmobileappbuilder.analytics.injector.PageViewBehaviorInjector.pageViewBehavior;
import ibmmobileappbuilder.ds.SearchOptions;
import ibmmobileappbuilder.ds.filter.Filter;
import java.util.Arrays;
import com.ibm.mobileappbuilder.testfeedback20160930045915.ds.ResponsetofeedbackDSSchemaItem;
import ibmmobileappbuilder.ds.CloudantDatasource;
import ibmmobileappbuilder.cloudant.factory.CloudantDatastoresFactory;
import java.net.URI;

public class ResponseDetailFragment extends ibmmobileappbuilder.ui.DetailFragment<ResponsetofeedbackDSSchemaItem> implements ShareBehavior.ShareListener  {

    private CrudDatasource<ResponsetofeedbackDSSchemaItem> datasource;
    private AnalyticsReporter analyticsReporter;
    public static ResponseDetailFragment newInstance(Bundle args){
        ResponseDetailFragment fr = new ResponseDetailFragment();
        fr.setArguments(args);

        return fr;
    }

    public ResponseDetailFragment(){
        super();
    }

    @Override
    public Datasource<ResponsetofeedbackDSSchemaItem> getDatasource() {
      if (datasource != null) {
        return datasource;
      }
       datasource = CloudantDatasource.cloudantDatasource(
              CloudantDatastoresFactory.create("responseforfeedback"),
              URI.create("https://dfe9cdad-0e3d-4ed2-8a81-818a2ed88267-bluemix:887073ee3dc99c65d4becdaa936c89d52359015007e10e44de1445f2c1f04417@dfe9cdad-0e3d-4ed2-8a81-818a2ed88267-bluemix.cloudant.com/responseforfeedback"),
              ResponsetofeedbackDSSchemaItem.class,
              new SearchOptions(),
              null
      );
        return datasource;
    }

    @Override
    public void onCreate(Bundle state) {
        super.onCreate(state);
addBehavior(pageViewBehavior("ResponseDetail"));
        analyticsReporter = AnalyticsReporterInjector.analyticsReporter(getActivity());
        // the presenter for this view
        setPresenter(new ResponseDetailPresenter(
                (CrudDatasource) getDatasource(),
                this));
        // Edit button
        addBehavior(new FabBehaviour(this, R.drawable.ic_edit_white, new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ((DetailCrudPresenter<ResponsetofeedbackDSSchemaItem>) getPresenter()).editForm(getItem());
            }
        }));
        addBehavior(new ShareBehavior(getActivity(), this));

    }

    // Bindings

    @Override
    protected int getLayout() {
        return R.layout.responsedetail_detail;
    }

    @Override
    @SuppressLint("WrongViewCast")
    public void bindView(final ResponsetofeedbackDSSchemaItem item, View view) {
        if (item.customer_name != null){
            
            TextView view0 = (TextView) view.findViewById(R.id.view0);
            view0.setText(item.customer_name);
            
        }
        if (item.customer_satisfaction != null){
            
            TextView view1 = (TextView) view.findViewById(R.id.view1);
            view1.setText(item.customer_satisfaction);
            
        }
        if (item.customer_email != null){
            
            TextView view2 = (TextView) view.findViewById(R.id.view2);
            view2.setText(item.customer_email);
            
        }
    }

    @Override
    protected void onShow(ResponsetofeedbackDSSchemaItem item) {
        // set the title for this fragment
        getActivity().setTitle("Back for list");
    }

    @Override
    public void navigateToEditForm() {
        Bundle args = new Bundle();

        args.putInt(Constants.ITEMPOS, 0);
        args.putParcelable(Constants.CONTENT, getItem());
        args.putInt(Constants.MODE, Constants.MODE_EDIT);

        Intent intent = new Intent(getActivity(), ResponsetofeedbackDSSchemaItemFormActivity.class);
        intent.putExtras(args);
        startActivityForResult(intent, Constants.MODE_EDIT);
    }
    @Override
    public void onShare() {
        ResponsetofeedbackDSSchemaItem item = getItem();

        Intent intent = new Intent();
        intent.setAction(Intent.ACTION_SEND);
        intent.setType("text/plain");

        intent.putExtra(Intent.EXTRA_TEXT, (item.customer_name != null ? item.customer_name : "" ) + "\n" +
                    (item.customer_satisfaction != null ? item.customer_satisfaction : "" ) + "\n" +
                    (item.customer_email != null ? item.customer_email : "" ));
        intent.putExtra(Intent.EXTRA_SUBJECT, "Back for list");
        analyticsReporter.sendEvent(analyticsInfo()
                            .withAction("share")
                            .withTarget((item.customer_name != null ? item.customer_name : "" ) + "\n" +
                    (item.customer_satisfaction != null ? item.customer_satisfaction : "" ) + "\n" +
                    (item.customer_email != null ? item.customer_email : "" ))
                            .withDataSource("ResponsetofeedbackDS")
                            .build().toMap()
        );
        startActivityForResult(Intent.createChooser(intent, getString(R.string.share)), 1);
    }
}

