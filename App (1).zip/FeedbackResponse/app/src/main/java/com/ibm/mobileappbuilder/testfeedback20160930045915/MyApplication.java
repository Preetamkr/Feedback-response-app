

package com.ibm.mobileappbuilder.testfeedback20160930045915;

import android.app.Application;
import ibmmobileappbuilder.injectors.ApplicationInjector;
import android.support.multidex.MultiDexApplication;
import ibmmobileappbuilder.analytics.injector.AnalyticsReporterInjector;
import ibmmobileappbuilder.cloudant.factory.CloudantDatabaseSyncerFactory;
import java.net.URI;


/**
 * You can use this as a global place to keep application-level resources
 * such as singletons, services, etc.
 */
public class MyApplication extends MultiDexApplication {

    @Override
    public void onCreate() {
        super.onCreate();
        ApplicationInjector.setApplicationContext(this);
        AnalyticsReporterInjector.analyticsReporter(this).init(this);
        //Syncing cloudant ds
        CloudantDatabaseSyncerFactory.instanceFor(
            "testfeedback",
            URI.create("https://63c774e2-582a-4e2a-890a-d34e3d6a9bdf-bluemix:fffe14301f9bcd0a44946e95c1d34cbaac78e026d47b2e1eca9dd27f497ac973@63c774e2-582a-4e2a-890a-d34e3d6a9bdf-bluemix.cloudant.com/testfeedback")
        ).sync(null);
          CloudantDatabaseSyncerFactory.instanceFor(
            "responseforfeedback",
            URI.create("https://dfe9cdad-0e3d-4ed2-8a81-818a2ed88267-bluemix:887073ee3dc99c65d4becdaa936c89d52359015007e10e44de1445f2c1f04417@dfe9cdad-0e3d-4ed2-8a81-818a2ed88267-bluemix.cloudant.com/responseforfeedback")
        ).sync(null);
      }
}

